This HDInsight source code is deprecated and will be removed in January 2017.

Please see the source code for the new Azure Resource Manager (ARM) mode commands for HDInsight:
https://github.com/Azure/azure-xplat-cli/tree/dev/lib/commands/arm/hdinsight
